import io
from pathlib import Path
from unittest import mock
from unittest.mock import MagicMock

import aiofiles
from fastapi.testclient import TestClient


@mock.patch("frontiers_review_assistant.services.llm_handler.Langfuse")
async def test_upload(langfuse_mock: MagicMock, client: TestClient):
    """
    Tests the behavior of PDF upload functionality and the integration with mocked Langfuse
    authentication checks.

    This test ensures that a PDF document can be successfully uploaded via a POST request,
    and that the response is correctly formatted as a text/event-stream. It simulates an
    authentication check via mocking and prepares the necessary test environment, including
    appropriate configurations for handling OCR.

    :param langfuse_mock: Mocked instance of the Langfuse service, used to simulate
        authentication checks.
    :param client: Instance of TestClient used to simulate API requests in the test environment.
    :return: None
    """
    langfuse_mock.return_value = MagicMock(auth_check=MagicMock(return_value=True))
    from frontiers_review_assistant.core.config import settings

    settings.OCR_TYPE = "llm_ocr"

    async with aiofiles.open(Path(__file__).parent / "data/chat_with_doc.pdf", "rb") as document:
        data = await document.read()
        response = client.post(
            url="/api/v1/upload/pdf",
            files={"file": ("chat_with_doc.pdf", io.BytesIO(data), "application/pdf")},
            data={
                "article_id": "1",
                "session_id": "2",
                "user_id": "3",
            },
        )

        assert response.status_code == 200
        assert response.headers["content-type"].startswith("text/event-stream")

        # Read the streamed response lines
        lines = [line for line in response.iter_lines() if line]
        # Decode bytes to string if needed
        _ = [line.decode() if isinstance(line, bytes) else line for line in lines]
