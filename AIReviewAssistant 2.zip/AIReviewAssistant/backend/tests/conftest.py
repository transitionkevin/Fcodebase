import os
import sys
from pathlib import Path

import pytest
from _pytest.fixtures import FixtureRequest
from fastapi.testclient import TestClient

sys.path.extend([str(Path(__file__).parent.parent)])


@pytest.fixture(autouse=True)
def client(test_engine):
    """
    Fixture to create a TestClient instance for the app. This fixture is autouse=True, meaning it will be executed before every test.

    Returns:
        TestClient: The TestClient instance for the app.
    """
    return test_engine


@pytest.fixture(scope="session")
def test_engine(request: FixtureRequest):
    """
    This function sets the testing environment variables and initializes the
    testing environment for the FastAPI application.

    It configures the application for testing by setting up the fake embedding
    class, initializing the logger with testing log level, and providing a
    TestClient instance to interact with the FastAPI app during tests.

    :param request: pytest fixture request object used for session management.
    :type request: FixtureRequest
    :return: A generator yielding a TestClient for testing the FastAPI application.
    :rtype: Generator[TestClient, None, None]
    """
    os.environ["ENVIRONMENT"] = "testing"

    from frontiers_review_assistant.core.config import settings
    from frontiers_review_assistant.server import app
    from frontiers_review_assistant.tools.service_logger import init_logger

    init_logger(settings.LOG_LEVEL)

    yield TestClient(app)

    os.environ["ENVIRONMENT"] = ""
