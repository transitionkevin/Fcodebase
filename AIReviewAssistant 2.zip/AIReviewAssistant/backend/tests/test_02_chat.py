from unittest import mock
from unittest.mock import MagicMock

import pytest
from fastapi.testclient import TestClient
from langfuse.api.resources.prompts.types import ChatMessage, Prompt_Chat
from langfuse.model import ChatPromptClient


@pytest.mark.asyncio
@mock.patch("frontiers_review_assistant.services.llm_handler.Langfuse")
async def test_review_assistant_chat(prompt_mock: MagicMock, client: TestClient):
    """
    Tests the chat functionality of the review assistant using the WebSocket connection.
    This test simulates user interactions with a WebSocket API for chat processing.

    The test uses a mocked Langfuse service and a mock chat prompt client with fallback
    configuration. It verifies the handling of a message request and ensures that a
    response event is received without producing any chat errors.

    :param prompt_mock: Mocked MagicMock object representing the prompt used by the chat
        functionality.
    :param client: TestClient instance to simulate the WebSocket connection.

    :return: None
    """
    fallback_client_args = {
        "name": "MockPrompt",
        "prompt": [
            ChatMessage(role="system", content="Mock System"),
            ChatMessage(role="human", content="{{context}} | {{query}} | {{format_instructions}}"),
        ],
        "type": "chat",
        "version": 0,
        "config": {"model": "mock-model", "temperature": 0.0},
        "labels": ["mock"],
        "tags": ["mock"],
    }
    prompt = ChatPromptClient(
        prompt=Prompt_Chat(**fallback_client_args),
        is_fallback=True,
    )
    prompt_mock.return_value = MagicMock(
        get_prompt=MagicMock(return_value=prompt),
        fetch_trace=MagicMock(
            return_value=MagicMock(
                data=MagicMock(
                    user_id=1,
                    session_id=11,
                    input="test-data",
                    output={"tags": ["t1", "t2"]},
                    metadata={"dummy": "no_idea"},
                )
            )
        ),
        trace=MagicMock(return_value=prompt),
    )

    with client.websocket_connect("/api/v1/ws/chat") as websocket:
        websocket.send_json(
            {
                "event_type": "on_message_request",
                "payload": {
                    "article_id": "1",
                    "session_id": "2",
                    "user_id": "devpits",
                    "query": "Why use AI chats in customer service?",
                },
            }
        )
        while True:
            data = websocket.receive_json()
            assert data["event_type"] != "on_chat_error"
            if data["event_type"] == "on_chat_response":
                websocket.send_json(
                    {
                        "event_type": "on_like_dislike",
                        "payload": {"message_id": "1", "flag": "like", "review": ""},
                    }
                )
                break
