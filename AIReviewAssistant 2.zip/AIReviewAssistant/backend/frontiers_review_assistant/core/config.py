import os
from typing import Literal, Self, cast

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # API Settings
    API_TITLE: str = "Frontiers Review Assistant API"
    API_DESCRIPTION: str = "API for processing and searching PDF documents"
    API_VERSION: str = "0.1.0"
    DEBUG: Literal["on", "off"] = "on"
    LOG_LEVEL: Literal["critical", "error", "warning", "info", "debug", "trace"] = "debug"

    # Vector Store Settings
    QDRANT_COLLECTION: str = "frontiers_collection"
    QDRANT_URL: str | None = None
    QDRANT_PORT: int = 6333
    QDRANT_API_KEY: str | None = None
    VECTOR_SIZE: int = 1536  # Size for text-embedding-3-small
    SPARSE_VECTOR_MODEL: str = "Qdrant/minicoil-v1"

    # OpenAI Settings
    DEFAULT_MODEL: str = "gpt-4.1-nano"
    OPENAI_API_KEY: str = ""
    EMBEDDING_MODEL: str = "text-embedding-3-small"
    EMBEDDING_CLASS: Literal["openai", "huggingface", "fake"] = "openai"
    CHUNK_SIZE: int = 600
    CHUNK_OVERLAP: int = 200
    BATCH_SIZE: int = 150

    # Document OCR
    OCR_SERVICE: Literal["on", "off"] = "off"
    OCR_TYPE: Literal["rapid_ocr", "llm_ocr"] = "rapid_ocr"
    OCR_LLM_MODEL: str = "gpt-4.1-nano"
    OCR_LLM_PROVIDER: str = "openai"
    OCR_LLM_MAX_TOKENS: int = 1024

    # Langfuse Settings
    LANGFUSE_PUBLIC_KEY: str = ""
    LANGFUSE_SECRET_KEY: str = ""
    LANGFUSE_HOST: str = ""

    # Application Settings
    MAX_RESULTS: int = 30
    PROMPT_ID: str = "frontiers-review-assistant:0.0.1"
    RETRIEVER_SEARCH_TYPE: str = "similarity"
    CHAIN_RUN_NAME: str = "Frontiers Review Assistant"

    # Server
    WORKERS: int = 1
    WS_MAX_QUEUE: int = 200
    FORWARDED_ALLOW_IPS: list[str] | str = "*"
    ENVIRONMENT: Literal["local", "testing", "staging", "production"] = "local"
    CONCURRENT_THREAD_COUNT: int = 100

    model_config = SettingsConfigDict(
        validate_default=False,
        env_prefix="",
        case_sensitive=False,
        extra="ignore",
        env_ignore_empty=True,
    )

    @model_validator(mode="after")
    def check_worker_config(self) -> Self:
        """

        :return:
        """
        # Binding open-akey with OS Environment
        if os.getenv("ENVIRONMENT") == "testing":  # pragma: no cover
            self.EMBEDDING_CLASS = "fake"
            self.OCR_LLM_PROVIDER = "fake"
            self.DEBUG = "on"
            self.OCR_SERVICE = "on"

        self.LOG_LEVEL = "debug" if self.DEBUG == "on" else self.LOG_LEVEL
        self.WORKERS = 1  # Hot fix [can't use multiple workers in in-memory qdrant]
        os.environ.setdefault("OPENAI_API_KEY", cast(str, self.OPENAI_API_KEY))
        os.environ.setdefault("LANGFUSE_PUBLIC_KEY", cast(str, self.LANGFUSE_PUBLIC_KEY))
        os.environ.setdefault("LANGFUSE_SECRET_KEY", cast(str, self.LANGFUSE_SECRET_KEY))
        os.environ.setdefault("LANGFUSE_HOST", self.LANGFUSE_HOST)
        os.environ.setdefault("CONCURRENT_THREAD_COUNT", str(self.CONCURRENT_THREAD_COUNT))

        return self


settings = Settings()
