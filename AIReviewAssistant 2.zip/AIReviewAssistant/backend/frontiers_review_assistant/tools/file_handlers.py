import tempfile
from pathlib import Path

import aiofiles
from fastapi import UploadFile

from frontiers_review_assistant.utils.exceptions import DocumentProcessingError


async def save_upload_file(file: UploadFile, directory: tempfile.TemporaryDirectory) -> Path:
    """
    Save an uploaded file to a temporary directory.

    Args:
        file: The uploaded file
        directory: The directory to save the file to

    Returns:
        The path to the saved file

    Raises:
        DocumentProcessingError: If there's an error saving the file
    """
    try:
        file_path = Path(directory.name) / file.filename.replace("(", "").replace(")", "")
        async with aiofiles.open(file_path, "wb") as source_file:
            chunk_size = 64 * 1024  # 64 KB chunks
            while True:
                chunk = await file.read(chunk_size)
                if not chunk:
                    break
                await source_file.write(chunk)
        return file_path
    except Exception as e:
        print(f"Error saving file: {str(e)}")  # Debug print
        raise DocumentProcessingError(f"Error saving file: {str(e)}") from e
