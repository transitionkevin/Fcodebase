import tempfile
from typing import Annotated

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from sse_starlette.sse import EventSourceResponse

from frontiers_review_assistant.core.config import settings
from frontiers_review_assistant.services.document import DocumentService
from frontiers_review_assistant.tools.file_handlers import save_upload_file
from frontiers_review_assistant.utils.exceptions import DocumentProcessingError

router = APIRouter(tags=["Upload"])


@router.post(
    "/upload/pdf",
    summary="Upload and process PDF with UnstructuredPDFLoader",
    response_class=EventSourceResponse,
)
async def upload_pdf(
    file: UploadFile = File(media_type="application/pdf", description="The PDF file to upload"),
    article_id: Annotated[str, Form(description="The ID of the article associated with this file")] = "",
    session_id: Annotated[str, Form(description="The ID of the session associated with this file")] = "",
    user_id: Annotated[str, Form(description="The ID of the user associated with this file")] = "",
):
    """
    Upload a PDF file and process it using UnstructuredPDFLoader.
    Returns server-sent events (SSE) with upload progress updates.

    Args:
        file: The PDF file to upload
        article_id: The ID of the article associated with this file
        session_id: The ID of the session associated with this file
        user_id: The ID of the user associated with this file

    Returns:
        Server-sent events with upload progress (25%, 50%, 75%, 100%)
    """

    try:
        # Create an async generator from the process_pdf method
        async def event_generator():
            async for event in DocumentService(
                file_path=file_path,
                article_id=article_id,
                session_id=session_id,
                user_id=user_id,
                chunk_size=settings.CHUNK_SIZE,
                chunk_overlap=settings.CHUNK_OVERLAP,
                batch_size=settings.BATCH_SIZE,
                embedding_model=settings.EMBEDDING_MODEL,
                embedding_class=settings.EMBEDDING_CLASS,
                ocr_type=settings.OCR_TYPE,
                ocr_llm_model=settings.OCR_LLM_MODEL,
                ocr_llm_provider=settings.OCR_LLM_PROVIDER,
                ocr_llm_max_tokens=settings.OCR_LLM_MAX_TOKENS,
            ).process_pdf(filename=file.filename.replace("(", "").replace(")", "")):
                yield event

        tmp_dir = tempfile.TemporaryDirectory(delete=False)
        file_path = await save_upload_file(file, tmp_dir)
        return EventSourceResponse(event_generator(), media_type="text/event-stream")

    except DocumentProcessingError as e:
        raise HTTPException(
            status_code=500,
            detail=str(e),
        ) from e
