from fastapi import APIRouter, WebSocket, WebSocketDisconnect, WebSocketException

from frontiers_review_assistant.services.review_assistant import (
    ChatMessage,
    ChatPipeline,
    LikeDislikeMessage,
)
from frontiers_review_assistant.tools.service_logger import logger
from frontiers_review_assistant.utils.exceptions import ChatError, EmptyContext

router = APIRouter(tags=["chat"])

# Initialize chat pipeline


@router.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):
    """WebSocket endpoint for chat functionality.

    Args:
        websocket: The WebSocket connection
    """

    article_id, session_id, chat_pipeline = None, None, None
    try:
        # Accept the connection
        await websocket.accept()
        chat_pipeline = ChatPipeline(websocket)

        # Process messages
        while message := await websocket.receive_json():  # pragma: no cover
            logger.debug(message)

            if message.get("event_type") == "on_message_request":
                chat_payload = ChatMessage(**message)
                article_id = chat_payload.payload.article_id
                session_id = chat_payload.payload.session_id
                user_id = chat_payload.payload.user_id
                try:
                    await chat_pipeline.search_knowledge_base(
                        query=chat_payload.payload.query,
                        article_id=article_id,
                        session_id=session_id,
                        user_id=user_id,
                    )

                except ChatError as e:
                    logger.error(f"Chat error: {e}")
                    await websocket.send_json(
                        {
                            "event_type": "on_chat_error",
                            "payload": {"error": str(e)},
                        }
                    )
                except EmptyContext as e:
                    logger.error(f"Chat error: {e}")
                    await websocket.send_json(
                        {
                            "event_type": "on_chat_error",
                            "payload": {"error": "No context found for the query"},
                        }
                    )
            elif message.get("event_type") == "on_like_dislike":
                like_dislike_payload = LikeDislikeMessage(**message)
                message_id = like_dislike_payload.payload.message_id
                flag = like_dislike_payload.payload.flag
                review_text = like_dislike_payload.payload.review
                try:
                    await chat_pipeline.like_dislike_handler(message_id, flag, review_text)
                except Exception as e:
                    logger.error(f"Failed to process like/dislike after retries: {e}")
                    await websocket.send_json(
                        {
                            "event_type": "on_like_dislike_error",
                            "payload": {"error": f"Failed to process like/dislike: {str(e)}"},
                        }
                    )

    except (WebSocketException, WebSocketDisconnect):  # pragma: no cover
        logger.debug(f"Closing connection for article_id: {article_id}")

        if article_id and session_id and chat_pipeline:
            await chat_pipeline.cleanup_session(article_id, session_id)
            logger.debug("Session cleaned up")
