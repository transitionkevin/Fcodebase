from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse

filepath = Path(__file__).parent.parent.parent.parent

router = APIRouter(tags=["download"])

FOLDER_PATH = filepath / "tests/data"


@router.get("/Document/DownloadPDF")
def download_file(articleId: int = Query()):  # pragma: no cover
    # List all files (sorted for consistency)
    files = sorted([f for f in FOLDER_PATH.iterdir() if f.is_file()])
    if not files:
        raise HTTPException(status_code=404, detail="No files found in the folder.")

    if articleId > len(files):
        raise HTTPException(status_code=404, detail=f"File with id {articleId} does not exist.")

    file_path = files[articleId - 1]  # id=1 returns 1st file, id=2 returns 2nd, etc.

    return FileResponse(path=str(file_path), filename=file_path.name, media_type="application/octet-stream")
