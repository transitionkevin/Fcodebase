import os
import typing
from contextlib import asynccontextmanager
from pathlib import Path

import anyio.to_thread
from fastapi import FastAPI
from fastapi.middleware import Middleware
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from starlette.datastructures import Headers
from starlette.middleware.cors import CORSMiddleware
from starlette.types import ASGIApp, Receive, Scope, Send

from frontiers_review_assistant.api.routes import chat, download_file, upload
from frontiers_review_assistant.core.config import settings

API_ALLOWED_HOSTS = [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:3020",
    "http://localhost:8080",
    "http://127.0.0.1:8080",
    "http://reviewassistant:8080",
    "http://0.0.0.0:8080",
    "https://review.frontiers-int1.info",
    "https://review.frontiers-int2.info",
    "https://review.frontiers-int3.info",
    "https://review.frontiers-int4.info",
    "https://review.frontiers-int8.info",
    "https://review.fuat-frontiersin.net",
    "https://review.test-frontiersin.net",
    "https://review.frontiersin.org",
]


@asynccontextmanager
async def lifespan(app: FastAPI):  # pragma: no cover
    """Application startup and shutdown events."""
    limiter = anyio.to_thread.current_default_thread_limiter()
    limiter.total_tokens = int(os.environ.get("CONCURRENT_THREAD_COUNT", 100))
    yield


def create_app():
    """
    Creates and configures the FastAPI application.

    This function initializes a FastAPI application with specific middlewares,
    routing, and settings dependent on the environment and configuration options.
    It ensures the application handles CORS, validates trusted client origins,
    and registers necessary API endpoints for functionality.

    :return: An instance of the configured FastAPI application
    :rtype: FastAPI
    """
    class TrustedClientMiddleware:
        def __init__(
            self,
            app: ASGIApp,
            allowed_hosts: typing.Sequence[str],
        ) -> None:
            self.app = app
            self.allowed_hosts = list(allowed_hosts)

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:  # pragma: no cover
            if "*" in self.allowed_hosts or scope.get("path") in [
                "/",
                "/openapi.json",
                "/healthcheck",
                "/static/frontiers-review-assistant.js",
                "/system/architecture/chat",
                "/system/architecture/upload",
            ]:  # pragma: no cover
                await self.app(scope, receive, send)
                return

            headers = Headers(scope=scope)
            client = headers.get("origin", "")
            is_valid_client = False

            for pattern in self.allowed_hosts:
                if pattern == client:
                    is_valid_client = True
                    break

            if not is_valid_client:
                response = PlainTextResponse("You're not allowed to access this application", status_code=400)
                await response(scope, receive, send)
            else:
                await self.app(scope, receive, send)
                return

    app = FastAPI(
        title=settings.API_TITLE,
        description=settings.API_DESCRIPTION,
        version=settings.API_VERSION,
        lifespan=lifespan,
        debug=settings.DEBUG == "on",
        docs_url="/",
        middleware=[
            Middleware(
                CORSMiddleware,
                allow_origins=API_ALLOWED_HOSTS,
                allow_credentials=True,
                allow_methods=["*"],
                allow_headers=["*"],
            ),
            Middleware(
                TrustedClientMiddleware,
                allowed_hosts=API_ALLOWED_HOSTS if settings.ENVIRONMENT in ["staging", "production"] else ["*"],
            ),
        ],
    )

    @app.get("/healthcheck", include_in_schema=True)
    async def healthcheck():  # pragma: no cover
        """
        Simple health check endpoint for the application.
        Returns a 200 OK response if the application is running.
        """
        return JSONResponse(status_code=200, content={"status": "ok", "message": "Service is running"})

    if settings.ENVIRONMENT not in ["local", "testing"]:  # pragma: no cover
        app.mount("/static", StaticFiles(directory=Path(__file__).parent.parent / "static"), name="static")

    app.include_router(upload.router, prefix="/api/v1")
    app.include_router(chat.router, prefix="/api/v1")
    app.include_router(download_file.router)
    return app


app = create_app()


@app.get("/system/architecture/chat", include_in_schema=False)
async def system_architecture_chat_page():  # pragma: no cover
    return HTMLResponse(
        content="""
    <!DOCTYPE html>
    <html>
    <head>
        <title>FastAPI with Mermaid</title>
        <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui.css" />
        <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
        <style>
            .mermaid-section {
                margin: 20px 0;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="mermaid-section">
            <h2>API Flow</h2>
            <div class="mermaid">
flowchart TD
    subgraph Input_Validation [Input Validation]
        Start([Start search_knowledge_base]) --> InputCheck{Is query empty?}
        InputCheck -->|Yes| EmptyError[Raise RuntimeError: Query empty]
        InputCheck -->|No| CreateRetriever[Create filtered retriever]
    end

    subgraph Component_Setup [Component Setup]
        CreateRetriever --> SetupComponents[Setup LLM components]
        SetupComponents --> |Get components| Components[/Output parser\nPrompt template\nChat model\nTemperature/]
        Components --> BuildChain[Build processing chain]
    end

    subgraph Chain_Building [Chain Building]
        BuildChain --> SetupRetriever[Setup retriever with filters]
        SetupRetriever --> InitLangfuse[Initialize Langfuse handler]
        InitLangfuse --> CreateChain[Create processing chain]

        subgraph Context_Processing [Context Processing]
            CreateChain --> RunParallel[RunnableParallel: Get query and context]
            RunParallel --> FormatContext[Format context from retrieved docs]
            FormatContext --> CheckContext{Context exists?}
            CheckContext -->|No| ContextError[Raise EmptyContext error]
            CheckContext -->|Yes| ApplyPrompt[Apply prompt template]
        end

        subgraph LLM_Processing [LLM Processing]
            ApplyPrompt --> RunLLM[Run LLM with context]
            RunLLM --> ParseOutput[Parse output to ReviewAssistance model]
        end
    end

    subgraph Response_Handling [Response Handling]
        InvokeChain[Invoke chain with query] --> Success{Success?}
        Success -->|Yes| ReturnResponse[Return ReviewAssistance response]
        Success -->|No| LogError[Log error]
        LogError --> RaiseError[Raise ChatError with details]
    end

    Input_Validation --> Component_Setup
    Component_Setup --> Chain_Building
    Chain_Building --> Response_Handling

    ReturnResponse --> End([End])
    EmptyError --> End
    ContextError --> LogError
    RaiseError --> End
            </div>
        </div>
    </body>
    </html>
    """
    )


@app.get("/system/architecture/upload", include_in_schema=False)
async def system_architecture_upload_page():  # pragma: no cover
    return HTMLResponse(
        content="""
    <!DOCTYPE html>
    <html>
    <head>
        <title>FastAPI with Mermaid</title>
        <link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@4.15.5/swagger-ui.css" />
        <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
        <style>
            .mermaid-section {
                margin: 20px 0;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="mermaid-section">
            <h2>API Flow</h2>
            <div class="mermaid">
flowchart TD
    start([Start process_pdf]) --> sse1[Send SSE: data loading 25%]
    sse1 --> loadChunks[Load Document Chunks]

    subgraph Document_Loading [Document Loading]
        loadChunks --> initLoader[Initialize PyMuPDF4LLMLoader]
        initLoader --> ocrCheck{OCR Enabled?}
    end

    subgraph OCR_Processing [OCR Processing]
        ocrCheck -->|Yes| ocrType{OCR Type?}
        ocrCheck -->|No| initSplitter[Initialize Document Splitter]
        ocrType -->|rapid_ocr| rapidOcr[Configure RapidOCRBlobParser]
        ocrType -->|llm_ocr| llmOcr[Configure LLMImageBlobParser]
        rapidOcr --> initSplitter
        llmOcr --> initSplitter
    end

    subgraph Chunking [Document Chunking]
        initSplitter --> embeddingType{Embedding Type?}
        embeddingType -->|OpenAI| tiktoken[Create Tiktoken Splitter]
        embeddingType -->|HuggingFace| hfSplitter[Create HF Tokenizer Splitter]
        embeddingType -->|Other| defaultSplitter[Create Default Splitter]
        tiktoken --> performChunk[Perform Document Chunking]
        hfSplitter --> performChunk
        defaultSplitter --> performChunk
        performChunk --> loadDocs[Load Documents]
        loadDocs --> splitDocs[Split Documents into Chunks]
    end

    Document_Loading --> OCR_Processing
    OCR_Processing --> Chunking

    splitDocs --> sse2[Send SSE: split doc 50%]
    sse2 --> upsertEmbeddings[Upsert Embeddings]

    subgraph Vector_Storage [Vector Storage]
        upsertEmbeddings --> initVectorStore[Initialize Vector Store]
        initVectorStore --> addMetadata[Add Metadata to Chunks]
        addMetadata --> batchProcess[Process in Batches]
        batchProcess --> storeVectors[Store Vectors in Database]
    end

    Chunking --> sse2
    sse2 --> Vector_Storage

    storeVectors --> sse3[Send SSE: completed 100%]
    sse3 --> cleanup[Clean Up Temporary Files]
    cleanup --> End([End Process])

    error[Error Handler] -.-> docError[Document Processing Error]
    error -.-> cleanup
            </div>
        </div>
    </body>
    </html>
    """
    )
