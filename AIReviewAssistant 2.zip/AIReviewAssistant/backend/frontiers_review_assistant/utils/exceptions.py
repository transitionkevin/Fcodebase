class ChatError(Exception):
    """Exception raised when there's an error in chat processing."""

    pass


class EmptyContext(Exception):
    """Exception raised when no context is found for a query."""

    pass


class DocumentProcessingError(Exception):
    """Exception raised when there's an error processing a document."""

    pass


class VectorStoreError(Exception):
    """Exception raised when there's an error with the vector store."""

    pass
