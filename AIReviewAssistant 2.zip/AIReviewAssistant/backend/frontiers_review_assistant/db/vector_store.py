from functools import lru_cache
from typing import Any, List

from langchain_community.embeddings.fake import DeterministicFakeEmbedding
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain_qdrant import QdrantVectorStore, RetrievalMode
from qdrant_client import QdrantClient, models

from frontiers_review_assistant.core.config import settings
from frontiers_review_assistant.tools.service_logger import logger

vector_store: QdrantVectorStore | None = None


@lru_cache(maxsize=1)
def get_qdrant_client() -> QdrantClient:
    """Get or create a Qdrant client instance."""
    if settings.QDRANT_URL:  # pragma: no cover
        client = QdrantClient(
            url=settings.QDRANT_URL,
            port=settings.QDRANT_PORT,
            api_key=settings.QDRANT_API_KEY,
            prefer_grpc=True,
        )
        logger.debug(f"Connected to Qdrant at {settings.QDRANT_URL}")
    elif settings.ENVIRONMENT == "local":  # pragma: no cover
        client = QdrantClient(path="vector_db")
        logger.debug("Using persistent memory Qdrant database")
    else:
        client = QdrantClient(":memory:")
        logger.debug("Using in-memory Qdrant database")
    return client


def initialize_vector_store(embedding_target) -> QdrantVectorStore:
    """Initialize the vector store with proper configuration."""
    global vector_store

    client = get_qdrant_client()
    provider, model_name = embedding_target.split(":")
    if provider == "openai":  # pragma: no cover
        embeddings = OpenAIEmbeddings(model=settings.EMBEDDING_MODEL, api_key=settings.OPENAI_API_KEY)
    elif provider == "huggingface":  # pragma: no cover
        embeddings = HuggingFaceEmbeddings(model_name=model_name)
    else:
        embeddings = DeterministicFakeEmbedding(size=settings.VECTOR_SIZE)

    # sparse_embeddings = FastEmbedSparse(model_name=settings.SPARSE_VECTOR_MODEL)

    if not client.collection_exists(collection_name=settings.QDRANT_COLLECTION):
        logger.debug("Creating Qdrant collection")
        client.create_collection(
            collection_name=settings.QDRANT_COLLECTION,
            vectors_config={
                "dense": models.VectorParams(
                    size=settings.VECTOR_SIZE,
                    distance=models.Distance.COSINE,
                    on_disk=True,
                    datatype=models.Datatype.FLOAT32,
                )
            },
            # sparse_vectors_config={
            #     "sparse": models.SparseVectorParams(
            #         modifier=models.Modifier.IDF,
            #     )
            # },
        )

    vector_store = QdrantVectorStore(
        client=client,
        collection_name=settings.QDRANT_COLLECTION,
        embedding=embeddings,
        # sparse_embedding=sparse_embeddings,
        validate_embeddings=False,
        validate_collection_config=False,
        retrieval_mode=RetrievalMode.DENSE,
        sparse_vector_name="sparse",
        vector_name="dense",
    )
    logger.debug("Initialized Qdrant vector store")
    return vector_store


async def add_documents(documents: List[Any]) -> None:
    """Add documents to the vector store."""
    await vector_store.aadd_documents(documents, batch_size=settings.BATCH_SIZE)
