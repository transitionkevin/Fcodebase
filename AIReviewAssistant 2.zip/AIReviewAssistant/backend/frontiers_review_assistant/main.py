import os
import sys
from pathlib import Path

import click
import uvicorn
from dotenv import find_dotenv, load_dotenv


@click.command()
@click.option(
    "--env",
    type=click.Choice(["local", "production"], case_sensitive=False),
    default="local",
    help="The environment to run the application in. Can be either 'local' or 'production'.",
)
@click.option(
    "--log-level",
    type=click.Choice(["critical", "error", "warning", "info", "debug", "trace"], case_sensitive=False),
    default="info",
    help="The log level to set. Can be one of 'critical', 'error', 'warning', 'info', 'debug', or 'trace'.",
)
@click.option(
    "--host",
    type=click.STRING,
    default="127.0.0.1",
    help="The host to run the application on. Defaults to '127.0.0.1'.",
)
@click.option(
    "--port",
    type=click.INT,
    default="8000",
    help="The port to run the application on. Defaults to '8000'.",
)
@click.option(
    "--reload",
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Whether to reload the application on changes. Defaults to 'off'.",
)
@click.option(
    "--debug",
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Whether to enable debug mode. Defaults to 'off'.",
)
@click.option(
    "--proxy",
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Whether to enable proxy mode. Defaults to 'off'.",
)
def run_server(
    env: str,
    log_level: str,
    host: str,
    port: int,
    reload: bool,
    debug: bool,
    proxy: bool,
):
    """
    Starts the server for the application with the specified configuration. The function
    accepts command-line options for setting the environment, log level, host, port, reload
    capability, debug mode, and proxy mode. The server is initialized with the appropriate
    settings and runs using Uvicorn as the ASGI server.

    """
    load_dotenv(find_dotenv(".env"))
    sys.path.extend([str(Path(__file__).parent.parent)])

    os.environ.setdefault("ENVIRONMENT", env)
    os.environ.setdefault("LOG_LEVEL", log_level)
    os.environ.setdefault("DEBUG", ("off", "on")[debug])

    from frontiers_review_assistant.core.config import settings
    from frontiers_review_assistant.tools.service_logger import init_logger

    init_logger(settings.LOG_LEVEL)

    uvicorn.run(
        app="frontiers_review_assistant.server:app",
        host=host,
        port=port,
        reload=reload,
        loop="uvloop" if os.name == "posix" else "asyncio",
        workers=settings.WORKERS,
        log_level=settings.LOG_LEVEL,
        log_config=None,
        forwarded_allow_ips=settings.FORWARDED_ALLOW_IPS,
        ws_max_queue=settings.WS_MAX_QUEUE,
        proxy_headers=proxy,
        use_colors=True,
        server_header=False,  # Security fix
    )


if __name__ == "__main__":
    run_server()
