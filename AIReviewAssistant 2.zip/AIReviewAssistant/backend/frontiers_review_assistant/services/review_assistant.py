import os
from typing import Literal, Optional

from fastapi.concurrency import run_in_threadpool
from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import (
    RunnableLambda,
    RunnableParallel,
    RunnablePassthrough,
)
from langchain_core.vectorstores import VectorStoreRetriever
from pydantic import BaseModel, Field
from qdrant_client import models
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed

from frontiers_review_assistant.core.config import settings
from frontiers_review_assistant.db.vector_store import initialize_vector_store
from frontiers_review_assistant.services.llm import load_chat_model
from frontiers_review_assistant.services.llm_handler import get_prompt_data, initialize_langfuse, load_langfuse_client
from frontiers_review_assistant.tools.service_logger import logger
from frontiers_review_assistant.utils.exceptions import ChatError, EmptyContext


class KnowledgeBaseSearch(BaseModel):
    query: str
    article_id: str | None = None


class ReviewAssistance(BaseModel):
    answer: str = Field(..., description="Answer to the question, always should be in plain text format")
    tags: list[str] = Field(
        ..., description="Assign one or more relevant tags (e.g., 'Abstract', 'Methods', 'Claims' based on the question"
    )


# WebSocket message models
class ChatMessageBody(BaseModel):
    """Model for chat messages sent by the client."""

    query: str = Field(..., description="The question or message from the user")
    article_id: str | None = Field(None, description="Optional article ID for filtering documents")
    session_id: str | None = Field(None, description="Optional session ID for tracking conversation")
    user_id: str | None = Field(None, description="Optional user ID for tracking conversation")


class ChatMessage(BaseModel):
    """Model for chat messages sent by the client."""

    event_type: Literal["on_message_request"] = Field(..., description="Event type")
    payload: ChatMessageBody = Field(..., description="Message body")


class LikeDislikeMessageBody(BaseModel):
    """Model for like/dislike messages sent by the client."""

    message_id: str = Field(..., description="The ID of the message being liked/disliked")
    flag: Literal["like", "dislike"] = Field(..., description="Whether the message was liked or disliked")
    review: Optional[str] = Field(None, description="Optional reviewer feedback text")


class LikeDislikeMessage(BaseModel):
    """Model for like/dislike messages sent by the client."""

    event_type: Literal["on_like_dislike"] = Field(..., description="Event type")
    payload: LikeDislikeMessageBody = Field(..., description="Message body")


class ChatResponse(BaseModel):
    """Model for chat responses sent by the server."""

    answer: str = Field(..., description="Answer to the question")
    suggested_questions: list[str] = Field(..., description="Suggested follow-up questions")
    session_id: str | None = Field(None, description="Session ID for tracking conversation")


class ChatPipeline:
    """Pipeline for processing chat messages and managing chat sessions."""

    def __init__(self, websocket, vector_store=None):
        """Initialize the chat pipeline.

        Args:
            vector_store: Optional vector store instance. If not provided, will be initialized.
        """
        self.vb = vector_store or initialize_vector_store(f"{settings.EMBEDDING_CLASS}:{settings.EMBEDDING_MODEL}")
        self._setup_environment()
        self.websocket = websocket
        self.langfuse = load_langfuse_client()
        self.langfuse_handler = None

    @staticmethod
    def _setup_environment():
        """Set up environment variables and initialize components."""
        os.environ.setdefault("OPENAI_API_KEY", settings.OPENAI_API_KEY)
        os.environ.setdefault("LANGFUSE_PUBLIC_KEY", settings.LANGFUSE_PUBLIC_KEY)
        os.environ.setdefault("LANGFUSE_SECRET_KEY", settings.LANGFUSE_SECRET_KEY)
        os.environ.setdefault("LANGFUSE_HOST", settings.LANGFUSE_HOST)

    def create_filtered_retriever(self, article_id: str, session_id: str):
        """Create a retriever with a filter for the specified article ID.

        Args:
            article_id: Optional ID to filter documents by
            session_id: Optional ID to filter documents by

        Returns:
            A configured retriever instance
        """
        search_filter = models.Filter(
            must=[
                models.FieldCondition(
                    key="metadata.article_id",
                    match=models.MatchValue(value=article_id),
                ),
                models.FieldCondition(
                    key="metadata.session_id",
                    match=models.MatchValue(value=session_id),
                ),
            ]
        )

        return self.vb.as_retriever(
            search_type=settings.RETRIEVER_SEARCH_TYPE,
            search_kwargs={
                "k": settings.MAX_RESULTS,
                "filter": search_filter,
                "hybrid_fusion": models.FusionQuery(fusion=models.Fusion.RRF),
            },
        )

    @staticmethod
    def setup_llm_components():
        """Set up the prompt template, output parser, and model configuration."""
        output_parser = PydanticOutputParser(pydantic_object=ReviewAssistance)
        format_instructions = output_parser.get_format_instructions()

        prompt_data = get_prompt_data(settings.PROMPT_ID)
        langchain_prompt = ChatPromptTemplate.from_messages(prompt_data["langchain_prompt"])
        langchain_prompt.metadata = {"langfuse_prompt": prompt_data["prompt"]}
        langchain_prompt = langchain_prompt.partial(format_instructions=format_instructions)

        chat_model = prompt_data["chat_model"]
        temperature = prompt_data["temperature"]

        return output_parser, langchain_prompt, chat_model, temperature

    def build_processing_chain(
        self,
        langchain_prompt: ChatPromptTemplate,
        chat_model: str,
        temperature: float,
        output_parser: PydanticOutputParser,
        retriever: VectorStoreRetriever,
        query: str,
        article_id: str,
        session_id: str,
        user_id: str,
    ):
        """Build the LLM processing chain with all components.

        Args:
            langchain_prompt: The prompt template to use
            chat_model: The model name to use for the LLM
            temperature: The temperature setting for the LLM
            output_parser: Parser for the LLM output
            retriever: Document retriever instance
            query: The user's query
            article_id: Optional article ID for tracking
            session_id: Optional session ID for tracking
            user_id: Optional user ID for tracking

        Returns:
            A configured processing chain
        """

        def format_context(input_dict):
            """Format the retrieved context into a string."""
            context_docs = input_dict.get("context", [])
            if not context_docs:
                raise EmptyContext("No context found for the query")
            context_texts = [doc.page_content for doc in context_docs]
            joined_context = "\n\n".join(context_texts)
            return {"query": input_dict["query"], "context": joined_context}

        env = os.getenv("ENVIRONMENT", "local")
        llm = load_chat_model(chat_model, provider="openai" if env != "testing" else "fake", temperature=temperature)

        self.langfuse_handler = initialize_langfuse(
            public_key=settings.LANGFUSE_PUBLIC_KEY,
            secret_key=settings.LANGFUSE_SECRET_KEY,
            host=settings.LANGFUSE_HOST,
            user_id=user_id,
            session_id=session_id,
            article_id=article_id,
        )

        chain = (
            RunnableParallel(query=RunnablePassthrough(), context=retriever)
            | RunnableLambda(format_context)
            | langchain_prompt
            | llm
            | output_parser
        ).with_config(
            run_name=settings.CHAIN_RUN_NAME,
            callbacks=[self.langfuse_handler],
            metadata={
                "question": query,
                "langfuse_session_id": session_id,
                "langfuse_user_id": user_id,
                "article_id": article_id,
            },
        )

        return chain

    async def search_knowledge_base(
        self, query: str, article_id: str | None, session_id: str | None, user_id: str | None
    ):
        """Search the knowledge base with the provided query and article ID.

        Args:
            query: The search query
            article_id: Optional article ID for filtering
            session_id: Optional session ID for tracking
            user_id: Optional user ID for tracking

        """
        try:
            # Validate input
            if not query.strip():
                raise RuntimeError("Query cannot be empty")

            retriever = self.create_filtered_retriever(article_id, session_id)
            output_parser, langchain_prompt, chat_model, temperature = self.setup_llm_components()

            chain = self.build_processing_chain(
                langchain_prompt=langchain_prompt,
                chat_model=chat_model,
                temperature=temperature,
                output_parser=output_parser,
                retriever=retriever,
                query=query,
                article_id=article_id,
                session_id=session_id,
                user_id=user_id,
            )

            response = await chain.ainvoke(query)
            result = response.model_dump()
            result["message_id"] = self.langfuse_handler.langfuse.trace_id

            await self.websocket.send_json({"event_type": "on_chat_response", "payload": result})

        except Exception as e:
            logger.debug(f"Error in knowledge search: {str(e)}")
            raise ChatError(
                f"An error occurred while processing your query: {str(e)}",
            ) from e

    async def cleanup_session(self, article_id: str, session_id: str):  # pragma: no cover
        """Clean up session data from the vector store.

        Args:
            article_id: The article ID to clean up
            session_id: The session ID to clean up
        """
        await run_in_threadpool(
            self.vb.client.delete,
            collection_name=settings.QDRANT_COLLECTION,
            points_selector=models.Filter(
                must=[
                    models.FieldCondition(
                        key="metadata.article_id",
                        match=models.MatchValue(value=article_id),
                    ),
                    models.FieldCondition(
                        key="metadata.session_id",
                        match=models.MatchValue(value=session_id),
                    ),
                ]
            ),
        )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_fixed(5),
        retry=retry_if_exception_type((Exception,)),
        before_sleep=lambda retry_state: logger.warning(
            f"Retrying like_dislike_handler (attempt {retry_state.attempt_number}): {retry_state.outcome.exception()}"
        ),
    )
    async def like_dislike_handler(
        self, message_id: str, flag: Literal["like", "dislike"], review_text: str | None = None
    ):
        """
        Handles user interaction for liking or disliking a chat result.

        This method processes a user's like or dislike response to a specific chat message.
        It fetches the trace data associated with the given message ID, updates the tags with
        the given flag (either "like" or "dislike"), and sends the updated trace information
        to the session. Additionally, an acknowledgment payload is sent back to the user
        through the WebSocket connection to confirm the operation status.

        :param message_id: The identifier of the chat message to be liked or disliked.
        :param flag: Specifies the action, either "like" or "dislike", to be applied to the chat message.
        :param review_text: Optional text review provided by the user commenting on their "like" or "dislike".
        :return: None
        """
        trace = await run_in_threadpool(self.langfuse.fetch_trace, id=message_id)
        input_query: str = f"""
Query: {trace.data.input}
ReviewText: {review_text}
"""
        input_query = input_query if review_text else trace.data.input
        output_data: dict = trace.data.output
        tags = output_data["tags"] + [flag]
        await run_in_threadpool(
            self.langfuse.trace,
            name="ReviewEntry",
            user_id=trace.data.user_id,
            session_id=trace.data.session_id,
            input=input_query,
            output=output_data,
            tags=tags,
            metadata=trace.data.metadata,
        )

        # Send acknowledgment
        await self.websocket.send_json(
            {
                "event_type": "on_like_dislike_response",
                "payload": {"message_id": message_id, "flag": flag, "status": "success"},
            }
        )
