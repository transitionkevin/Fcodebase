from typing import Any, Optional

from langchain.chat_models import init_chat_model
from langchain_core.callbacks.manager import AsyncCallbackManagerForLLMRun
from langchain_core.language_models.fake_chat_models import FakeChatModel
from langchain_core.messages.ai import AIMessage
from langchain_core.messages.base import BaseMessage
from langchain_core.outputs.chat_generation import ChatGeneration
from langchain_core.outputs.chat_result import ChatResult
from typing_extensions import override


class MockChatModel(FakeChatModel):
    """Fake Chat Model wrapper for testing purposes."""

    @override
    async def _agenerate(
        self,
        messages: list[BaseMessage],
        stop: Optional[list[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        output_str = """{"answer": "answer", "tags": ["tag1" ,"tag2"]}"""
        message = AIMessage(content=output_str)
        generation = ChatGeneration(message=message)
        return ChatResult(generations=[generation])


def load_chat_model(model: str, provider: str, **kwargs):
    if provider == "fake":
        return MockChatModel()

    return init_chat_model(model=model, model_provider=provider, **kwargs)  # pragma: no cover
