from langfuse import Langfuse
from langfuse.callback import CallbackHandler

from frontiers_review_assistant.core.config import settings
from frontiers_review_assistant.tools.service_logger import logger


def load_langfuse_client():
    """
    Initializes and loads a Langfuse client.

    This function creates an instance of the Langfuse client and performs an
    authentication check to ensure the client is properly configured and ready
    to use. The authentication check is critical to ensure secure and correct
    operation. If the check fails, an assertion error will be raised.

    :return: An authenticated Langfuse client instance.
    :rtype: Langfuse
    """
    langfuse = Langfuse()
    assert langfuse.auth_check()
    return langfuse


def initialize_langfuse(
    public_key: str, secret_key: str, host: str, article_id: str, session_id: str, user_id: str
):  # pragma: no cover
    """
    Initializes and configures the Langfuse handler with provided parameters for
    authentication, session tracking, and metadata. This function validates the
    authentication setup and initializes a callback handler to manage interactions
    with Langfuse's services. If the environment is "testing," a mock handler is
    returned.

    :param public_key: API public key for authenticating with Langfuse service
    :param secret_key: API secret key for authenticating with Langfuse service
    :param host: Host URL for the Langfuse server
    :param article_id: Identifier for the associated article, used as metadata
    :param session_id: Identifier for the session, used in session tracking
    :param user_id: Unique identifier of the user
    :return: Returns a Langfuse `CallbackHandler` instance for interacting with the
        Langfuse API. In "testing" environment, a `StdOutCallbackHandler` is
        returned instead.
    """
    langfuse_handler = CallbackHandler(
        public_key=public_key,
        secret_key=secret_key,
        host=host,
        user_id=user_id,
        session_id=session_id,
        metadata={"article_id": article_id},
        environment=settings.ENVIRONMENT,
        tags=["review_assistant", settings.ENVIRONMENT],
    )
    load_langfuse_client()
    return langfuse_handler


def get_prompt_data(prompt_id: str):
    """
    Retrieve and construct data related to a specific prompt using its ID. The function fetches the prompt's details
    from an external source, processes it into a LangChain format, and extracts relevant configuration parameters
    to organize them into a structured dictionary.

    :param prompt_id: The unique identifier of the prompt to retrieve.
    :type prompt_id: str
    :return: A dictionary containing the prompt, its LangChain equivalent, and associated configuration details such as
        the model and temperature.
    :rtype: dict
    """
    langfuse = Langfuse()
    prompt = langfuse.get_prompt(prompt_id, type="chat", label="latest")
    chat_prompt = prompt.get_langchain_prompt()
    model = prompt.config.get("model", settings.DEFAULT_MODEL)
    temperature = prompt.config.get("temperature", 0.0)

    logger.debug(prompt)
    return {
        "prompt": prompt,
        "langchain_prompt": chat_prompt,
        "chat_model": model,
        "temperature": temperature,
    }
