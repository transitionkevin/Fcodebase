import shutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Literal

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders.pdf import PyPDFLoader
from langchain_text_splitters.base import TS
from starlette.concurrency import run_in_threadpool
from transformers import AutoTokenizer

from frontiers_review_assistant.db.vector_store import (
    add_documents,
    initialize_vector_store,
)
from frontiers_review_assistant.tools.service_logger import logger
from frontiers_review_assistant.utils.exceptions import DocumentProcessingError


def sse_event(event: str, data: dict) -> Dict[str, str]:
    """
    Generates a server-sent event (SSE) response containing the provided event name and data.
    This function formats the input as a dictionary appropriate for use with SSE clients.

    :param event: The name of the event to be sent to the client.
    :type event: str
    :param data: A dictionary containing the data payload to be associated with the event.
    :type data: dict
    :return: A dictionary with the keys "event" (containing the event name) and "data"
        (containing the corresponding data payload).
    :rtype: Dict[str, str]
    """
    return {"event": event, "data": data}


LLM_MODEL_NAME = "gpt-4.1-nano"
LLM_MAX_TOKENS = 1024
LLM_RUN_NAME = "DocumentParsing"
LLM_SESSION_ID = "document-parsing"
LLM_USER_ID = "dev-test"


class DocumentService:
    """Service for handling document processing and storage."""

    def __init__(
        self,
        file_path: Path,
        article_id: str,
        session_id: str,
        user_id: str,
        chunk_size: int = 600,
        chunk_overlap: int = 200,
        batch_size: int = 100,
        embedding_model: str = "sentence-transformers/all-mpnet-base-v2",
        embedding_class: Literal["openai", "huggingface", "fake"] = "openai",
        ocr_type: Literal["rapid_ocr", "llm_ocr"] = "rapid_ocr",
        ocr_llm_model: str = "gpt-4.1-nano",
        ocr_llm_provider: str = "openai",
        ocr_llm_max_tokens: int = 1024,
    ):
        self.file_path = file_path
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.embedding_model = embedding_model
        self.embedding_class = embedding_class
        self.ocr_type = ocr_type
        self.ocr_llm_model = ocr_llm_model
        self.ocr_llm_provider = ocr_llm_provider
        self.ocr_llm_max_tokens = ocr_llm_max_tokens
        self.batch_size = batch_size
        self.session_id = session_id
        self.user_id = user_id
        self.article_id = article_id

    @staticmethod
    def _init_document_loader(file_path: Path) -> PyPDFLoader:
        """Initialize the document loader with the appropriate image parser."""
        return PyPDFLoader(file_path=file_path, extraction_mode="layout", mode="single")

    def _init_document_spliter(self) -> TS:
        """
        Initializes and returns a document splitter based on the embedding class.

        This method creates a document splitter instance by selecting the splitting
        mechanism depending on the value of the `embedding_class` attribute. Different
        encoders or tokenizers are employed for processing the text for OpenAI or
        Huggingface embeddings. If the specified `embedding_class` is unsupported, a
        default `RecursiveCharacterTextSplitter` instance is returned.

        :return: An instance of the document splitter to segment text.
        :rtype: TS
        """
        if self.embedding_class == "openai":  # pragma: no cover
            logger.info("Using OpenAI encoder for text splitting")
            spliter = RecursiveCharacterTextSplitter.from_tiktoken_encoder(
                encoding_name="cl100k_base",
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                add_start_index=True,
            )
        elif self.embedding_class == "huggingface":  # pragma: no cover
            logger.info("Using Huggingface tokenizer for text splitting")
            tokenizer = AutoTokenizer.from_pretrained(self.embedding_model)
            spliter = RecursiveCharacterTextSplitter.from_huggingface_tokenizer(
                tokenizer=tokenizer,
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
        else:
            spliter = RecursiveCharacterTextSplitter()
        return spliter

    @staticmethod
    async def perform_document_chunking(spliter: TS, loader: PyPDFLoader):
        """
        Perform the chunking of documents provided by the loader using the specified splitter.

        This method asynchronously fetches documents from the loader and applies the
        splitter to split them into smaller chunks.

        :param spliter: A splitter instance used to divide the documents into smaller chunks.
        :param loader: An asynchronous loader instance that retrieves the documents.
        :return: A list of document chunks after splitting.
        :rtype: List[Document]
        """
        docs = await loader.aload()
        chunks = spliter.split_documents(docs)
        return chunks

    async def load_document_chunks(self, file_path: Path):
        """
        Asynchronously loads and processes document chunks.

        This method initializes a document loader for the specified file path, then
        initializes a document splitter to divide the document into manageable
        chunks. The actual chunking process is performed asynchronously and
        returns the resulting list of document chunks.

        :param file_path: The path to the file that will be loaded and processed.
        :type file_path: str
        :return: A list of document chunks extracted and processed from the file.
        :rtype: list
        """
        logger.info(f"Loading document from {file_path}")
        document_loader = self._init_document_loader(file_path)
        logger.info("Document spliter initialized, starting chunking process...")
        document_spliter = self._init_document_spliter()
        chunks = await self.perform_document_chunking(document_spliter, document_loader)

        return chunks

    async def upsert_embeddings(self, chunks, document_metadata: dict):
        """
        Asynchronously inserts or updates embeddings in the vector store. This method
        takes in a list of chunks (document pieces) and corresponding metadata
        to initialize and batch process the storage of embeddings. The embeddings
        are processed in batches of a predefined size to optimize the insertion
        process.

        :param chunks: A list of document chunks, where each chunk represents a
            portion of a document to be stored in the vector store.
        :param document_metadata: Dictionary containing metadata information about
            the document, such as source, title, or other contextual details.
        :return: None
        """
        initialize_vector_store(f"{self.embedding_class}:{self.embedding_model}")
        for chunk in chunks:
            chunk.metadata = document_metadata

        await add_documents(chunks)

    async def process_pdf(
        self,
        filename: str,
    ):
        """
        Process a PDF file and store its chunks in the vector store.

        Args:
            filename: filename of the PDF file

        Returns:
            Information about the processed document
        """
        try:
            logger.info(f"Processing PDF file: {filename}")
            yield sse_event("upload status", {"message": "data loading", "progress": 25})
            chunks = await self.load_document_chunks(self.file_path)
            logger.info(f"Document loading completed, Number of chunks: {len(chunks)}")
            yield sse_event("upload status", {"message": "split doc", "progress": 50})
            await self.upsert_embeddings(
                chunks=chunks,
                document_metadata={
                    "article_id": self.article_id,
                    "session_id": self.session_id,
                    "user_id": self.user_id,
                    "filename": filename,
                    "timestamp": datetime.now().isoformat(),
                },
            )
            logger.info(f"Process completed file: {filename}")
            yield sse_event("upload status", {"message": "completed", "progress": 100})

        except Exception as e:
            raise DocumentProcessingError(f"Error processing PDF file: {str(e)}") from e
        finally:
            await run_in_threadpool(shutil.rmtree, str(self.file_path.parent))
